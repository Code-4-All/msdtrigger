﻿Imports System.Runtime.InteropServices

<ComImport()>
<ComVisible(True)>
<Guid("79eac9d5-bafa-11ce-8c82-00aa004ba90b")>
<InterfaceType(ComInterfaceType.InterfaceIsIUnknown)>
Public Interface IWindowForBindingUI
    'HRESULT GetWindow([in]  REFGUID rguidReason, [out] HWND* phwnd);
    <PreserveSig()>
    Function GetWindow(<[In]()> ByRef rguidReason As Guid, <[In](), Out()> ByRef phwnd As IntPtr) As <MarshalAs(UnmanagedType.I4)> Int32
End Interface


<ComImport()>
<ComVisible(True)>
<Guid("79eac9d7-bafa-11ce-8c82-00aa004ba90b")>
<InterfaceType(ComInterfaceType.InterfaceIsIUnknown)>
Public Interface IHttpSecurity

    'Parent: IWindowForBindingUI
    'HRESULT GetWindow([in]  REFGUID rguidReason, [out] HWND* phwnd);
    <PreserveSig()>
    Function GetWindow(<[In]()> ByRef rguidReason As Guid, <[In](), Out()> ByRef phwnd As IntPtr) As <MarshalAs(UnmanagedType.I4)> Int32

    'HRESULT OnSecurityProblem([in] DWORD dwProblem);
    <PreserveSig()>
    Function OnSecurityProblem(<[In](), MarshalAs(UnmanagedType.U4)> dwProblem As UInt32) As <MarshalAs(UnmanagedType.I4)> Int32
End Interface

<ComImport()>
<ComVisible(True)>
<Guid("6D5140C1-7436-11CE-8034-00AA006009FA")>
<InterfaceType(ComInterfaceType.InterfaceIsIUnknown)>
Public Interface IMyServiceProvider

    <PreserveSig()>
    Function QueryService(<[In]()> ByRef guidService As Guid,
                          <[In]()> ByRef riid As Guid,
                          <Out()> ByRef ppvObject As IntPtr) As <MarshalAs(UnmanagedType.I4)> Int32

End Interface