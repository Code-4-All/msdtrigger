﻿Imports System.IO
Imports System.Threading

Public Class DummyForm

#Region "Deklarationen"

    ''' <summary>
    ''' Enthält die aus der Konfigurationsdatei eingelesenen Daten.
    ''' </summary>
    Private config As AppConfig
    ''' <summary>
    ''' Schreibt Daten in die Logdatei.
    ''' </summary>
    Private swLog As StreamWriter
    ''' <summary>
    ''' Dient als Checkpoint, um auf den Abschluss einer Teilanforderung zu warten
    ''' </summary>
    Private areLoopLock As New AutoResetEvent(False)
    ''' <summary>
    ''' True, wenn die aktuelle Anfrage die Backupanfrage ist, sonst False (und damit die Lösch-Anfrage)
    ''' </summary>
    Private isBackup As Boolean
    ''' <summary>
    ''' True, wenn die WebBrowser-Komponente den Ladevorgang wegen eines Zertifikatsfehlers abgebrochen hat.
    ''' </summary>
    Private wasSecError As Boolean
    ''' <summary>
    ''' True, wenn das Programm aufgrund eines Fehlers sofort beendet werden soll.
    ''' </summary>
    Private errorExit As Boolean
    ''' <summary>
    ''' WebBrowser-Komponente, die alle Seitenaufrufe ausführt.
    ''' </summary>
    Private WithEvents wb As WebBrowser

#End Region

    ''' <summary>
    ''' Konstruktor. Initialisiert die WebBrowser-Komponente und die Logdatei.
    ''' </summary>
    ''' <param name="config">Eine AppConfig-Instanz, die die eingelesene Konfiguration enthält.</param>
    Public Sub New(config As AppConfig)
        InitializeComponent()
        Me.config = config
        Me.Visible = False

        If config.DisableCertValidation Then
            wb = New SslWebBrowser
        Else
            wb = New WebBrowser
        End If

        wb.ScriptErrorsSuppressed = True
        Me.Controls.Add(wb)

        swLog = New StreamWriter(config.LogFile, True)
        swLog.AutoFlush = True

        Me.CreateHandle()
    End Sub

    ''' <summary>
    ''' Startet einen Arbeitsthread, der die Seitenaufrufe initialisiert.
    ''' </summary>
    Private Sub DummyForm_HandleCreated(sender As Object, e As System.EventArgs) Handles Me.HandleCreated
        ThreadPool.QueueUserWorkItem(AddressOf ThreadWorker)
    End Sub

    ''' <summary>
    ''' Führt für jede ConfigEntry-Sektion der Konfiguration die dort angegebenen URL-Anfragen aus.
    ''' </summary>
    Private Sub ThreadWorker(state As Object)
        LogEntry("Operation started, " & config.Entries.Length & " request(s) queued.")

        For Each e In config.Entries
            isBackup = True
            LogEntry("Accessing " & e.BackupRequestUrl)
            Me.Invoke(New Action(Of ConfigEntry)(AddressOf DoNavigation), e)
            areLoopLock.WaitOne()

            If errorExit Then Exit For

            isBackup = False
            LogEntry("Accessing " & e.CleanupRequestUrl)
            Me.Invoke(New Action(Of ConfigEntry)(AddressOf DoNavigation), e)
            areLoopLock.WaitOne()

            If errorExit Then Exit For
        Next

        LogEntry("Operation finished.")
        Me.Invoke(New Action(AddressOf ExitApp))
    End Sub

    ''' <summary>
    ''' Übergibt der WebBrowser-Komponente die auszuführende Anfrage.
    ''' </summary>
    Private Sub DoNavigation(e As ConfigEntry)
        Dim parts() As String

        If isBackup Then
            parts = e.BackupRequestUrl.Split(New String() {"://"}, StringSplitOptions.None)
        Else
            parts = e.CleanupRequestUrl.Split(New String() {"://"}, StringSplitOptions.None)
        End If

        wb.Navigate(String.Format("{0}://{1}:{2}@{3}", parts(0), e.Username, e.Password, parts(1)))
    End Sub

    ''' <summary>
    ''' Tritt ein, wenn die WebBrowser-Komponente eine Seite vollständig geladen hat.
    ''' </summary>
    Private Sub wb_DocumentCompleted(sender As Object, e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles wb.DocumentCompleted

        'SSL-Fehler ignorieren
        If wb.DocumentText.Contains("securityError") Then
            If config.DisableCertValidation Then
                LogEntry("WARNING: Invalid SSL certificate.")
                wasSecError = True
                wb.Refresh()
            Else
                LogEntry("ERROR: Invalid SSL certificate.")
                errorExit = True
                areLoopLock.Set()
            End If

            Return
        End If

        'Ladeabbruch durch Refresh ignorieren
        If wb.DocumentText.Contains("Navigation to the webpage was canceled") Then
            If wasSecError Then
                wb.Refresh()
                wasSecError = False
            Else
                LogEntry("ERROR: Could not navigate to " & e.Url.ToString())
                errorExit = True
                areLoopLock.Set()
            End If

            Return
        End If

        If isBackup Then
            If wb.DocumentText.Contains("document.dump.submit()") Then
                Return
            End If

            LogEntry("Backup done.")
        Else
            LogEntry("Cleanup successful.")
        End If

        areLoopLock.Set()
    End Sub

    ''' <summary>
    ''' Schreibt eine Zeile in die Logdatei.
    ''' </summary>
    Private Sub LogEntry(message As String)
        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of String)(AddressOf LogEntry), message)
        Else
            swLog.WriteLine("{0} {1}", Date.Now().ToString("yyyy-MM-dd HH:mm:ss"), message)
        End If
    End Sub

    ''' <summary>
    ''' Gibt benutzte Ressourcen frei und beendet dann die Anwendung.
    ''' </summary>
    Private Sub ExitApp()
        areLoopLock.Close()
        wb.Dispose()
        swLog.Flush()
        swLog.Close()
        Application.Exit()
    End Sub

End Class
