﻿Imports System.Runtime.InteropServices

''' <summary>
''' Ableitung des vorhandenen WebBrowser-Controls, die alle Zertifikatswarnungen ignorieren kann.
''' </summary>
<ComVisible(True)>
Public Class SslWebBrowser
    Inherits WebBrowser

    Protected Overrides Function CreateWebBrowserSiteBase() As System.Windows.Forms.WebBrowserSiteBase
        Return New SslWebBrowserSite(Me)
    End Function

    Private Class SslWebBrowserSite
        Inherits WebBrowserSite
        Implements IMyServiceProvider
        Implements IWindowForBindingUI
        Implements IHttpSecurity

        Private Const RPC_E_RETRY As Int32 = &H80010109
        Private Const E_NOINTERFACE As Int32 = &H80004002
        Private Const S_OK As Int32 = 0
        Private Const S_FALSE As Int32 = 1
        Private ReadOnly IID_IHttpSecurity As New Guid("79eac9d7-bafa-11ce-8c82-00aa004ba90b")
        Private ReadOnly IID_IWindowForBindingUI As New Guid("79eac9d5-bafa-11ce-8c82-00aa004ba90b")
        Private wbParent As WebBrowser

        Public Sub New(parent As WebBrowser)
            MyBase.New(parent)
            Me.wbParent = parent
        End Sub

        Public Function GetWindow(ByRef rguidReason As System.Guid, ByRef phwnd As System.IntPtr) As Integer _
            Implements IHttpSecurity.GetWindow, IWindowForBindingUI.GetWindow

            If rguidReason = IID_IHttpSecurity Or rguidReason = IID_IWindowForBindingUI Then
                phwnd = wbParent.Handle
                Return S_OK
            Else
                phwnd = IntPtr.Zero
                Return S_FALSE
            End If
        End Function

        Public Function OnSecurityProblem(dwProblem As UInteger) As Integer Implements IHttpSecurity.OnSecurityProblem
            Return S_OK
        End Function

        Public Function QueryService(ByRef guidService As System.Guid, ByRef riid As System.Guid, ByRef ppvObject As System.IntPtr) As Integer Implements IMyServiceProvider.QueryService
            If riid = IID_IWindowForBindingUI Then
                ppvObject = Marshal.GetComInterfaceForObject(Me, GetType(IWindowForBindingUI))
                Return S_OK
            End If

            If riid = IID_IHttpSecurity Then
                ppvObject = Marshal.GetComInterfaceForObject(Me, GetType(IHttpSecurity))
                Return S_OK
            End If

            ppvObject = IntPtr.Zero
            Return E_NOINTERFACE
        End Function

    End Class

End Class