﻿Imports System.IO
Imports System.Xml.Serialization

''' <summary>
''' Wrapper für die XML-Anwendungskonfiguration.
''' </summary>
<Serializable()>
Public Class AppConfig
    Property Entries As ConfigEntry()
    Property LogFile As String
    Property DisableCertValidation As Boolean
    Property ResumeOnError As Boolean

    ''' <summary>
    ''' Liest eine programmkonforme Konfigurationsdatei ein.
    ''' </summary>
    ''' <param name="path">Der Pfad zur Konfigurationsdatei.</param>
    ''' <returns>Eine AppConfig-Instanz, deren Inhalt aus der Konfigurationsdatei geladen wurde.</returns>
    Public Shared Function ReadFile(path As String) As AppConfig
        Using fs As New FileStream(path, FileMode.Open)
            Dim xs As New XmlSerializer(GetType(AppConfig))
            Return CType(xs.Deserialize(fs), AppConfig)
        End Using
    End Function

    ''' <summary>
    ''' Speichert den aktuellen Zustand der AppConfig-Instanz in eine XML-Datei.
    ''' </summary>
    ''' <param name="path">Der Pfad zur Datei, in die der Objektzustand gespeichert werden soll.</param>
    Public Sub SaveFile(path As String)
        Using fs As New FileStream(path, FileMode.Create)
            Dim xs As New XmlSerializer(GetType(AppConfig))
            xs.Serialize(fs, Me)
        End Using
    End Sub
End Class

''' <summary>
''' Respräsentiert einen Backup-Auftrag in der Konfiguration.
''' </summary>
<Serializable()>
Public Class ConfigEntry
    Property BackupRequestUrl As String
    Property CleanupRequestUrl As String
    Property Username As String
    Property Password As String
End Class