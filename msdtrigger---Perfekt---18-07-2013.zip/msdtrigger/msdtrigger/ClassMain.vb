﻿Imports System.IO
Imports System.Net
Imports System.Threading

Public Class ClassMain

    'Create a config file:
    'Dim c As New AppConfig
    'c.LogFile = "msdtrigger.log"

    'Dim e As New ConfigEntry
    'e.BackupRequestUrl = "https://example.com/dump.php?config=mysqldumper"
    'e.CleanupRequestUrl = "https://example.com/filemanagement.php?action=files"
    'e.Username = "test"
    'e.Password = "abcd"

    'c.Entries = New ConfigEntry() {e}
    'c.SaveFile("msdtrigger.xml")

    ''' <summary>
    ''' Einstiegspunkt der Anwendung. Liest die Konfigurationsdatei von einem festgelegten Pfad und startet das Backup.
    ''' </summary>
    Public Shared Sub Main()
        If Not File.Exists("msdtrigger.xml") Then Environment.Exit(1)
        Dim config As AppConfig = Nothing

        Try
            config = AppConfig.ReadFile("msdtrigger.xml")
        Catch ex As Exception
            Environment.Exit(1)
        End Try

        Dim f As New DummyForm(config)
        Application.Run()
    End Sub

End Class
